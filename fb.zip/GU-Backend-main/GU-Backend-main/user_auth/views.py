from django.shortcuts import render


from django.core.mail import send_mail
from django.utils import timezone
from django.contrib.auth.models import User
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate
from rest_framework.views import APIView
from rest_framework.response import Response
from .models import EmailOTP
import random
from rest_framework import status
from users.serializer import *
from users.authentication import *

class RegisterView(APIView):
    def post(self, request):
        serializer = UserSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            otp = str(random.randint(000000, 999999))
            EmailOTP.objects.update_or_create(
                email=user,
                otp = otp
            )

            send_mail(
                subject="Your OTP Code",
                message=f"Yo bruh, your OTP is {otp}",
                from_email="noreply@otp.com",
                recipient_list=[user.Email_Address],
            )
            token = generate_token(user)
            return Response({'token': token}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    



class RegisterVerify(APIView):
    authentication_classes = [IsAuthenticated]
    def post(self, request):
        user = request.user
        email = user.Email_Address
        otp = request.data.get('otp')


        if user.is_verified == True:
            return Response({'msg': ' user already verified'}, status=400)
        if not otp:
            return Response({'error': ' OTP is required'}, status=400)  
        try:
            record = EmailOTP.objects.get(email=user)
        except EmailOTP.DoesNotExist:
            return Response({'error': 'user not found'}, status=404)

        if record.otp != otp:
            return Response({'error': 'Invalid OTP'}, status=400)

  

        user.is_verified = True
        user.save()
        return Response({'message': 'User registered successfully ✅'})


# dhanush login view

# class LoginView(APIView):
#     def post(self, request):
#         email = request.data.get('email')
#         password = request.data.get('password')
#         user = UserDetails.objects.get(Email_Address=email)
#         print(email,password,user)
#         if user.is_verified == False: 
#             otp = str(random.randint(000000, 999999))
#             EmailOTP.objects.update_or_create(
#                 email=user,
#                 defaults={'otp': otp}
#             )

#             send_mail(
#                 subject="Your OTP Code",
#                 message=f"Yo bruh, your OTP is {otp}",
#                 from_email="noreply@otp.com",
#                 recipient_list=[user.Email_Address],
#             )
#             token = generate_token(user)
#             return Response({'token': token}, status=status.HTTP_200_OK)
#         elif user and password==user.Password and user.is_verified == True:
#             token = generate_token(user)
#             return Response({'token': token}, status=status.HTTP_200_OK)
#         return Response({'error': 'Invalid credentials'}, status=status.HTTP_401_UNAUTHORIZED)


class LoginView(APIView):
    def post(self, request):
        email = request.data.get('email')
        password = request.data.get('password')

        try:
            user = UserDetails.objects.get(Email_Address=email)
        except UserDetails.DoesNotExist:
            return Response({'error': 'User not found'}, status=404)

        if user.Password != password:
            return Response({'error': 'Incorrect password'}, status=401)

        if not user.is_verified:
            return Response({'error': 'User not verified. Please verify your email OTP.'}, status=403)

        # Login success
        token = generate_token(user)
        return Response({'token': token}, status=200)


from django.contrib.auth.hashers import make_password

class ResetPasswordView(APIView):
    def post(self, request):
        email = request.data.get('email')
        otp = request.data.get('otp')
        new_password = request.data.get('new_password')

        if not all([email, otp, new_password]):
            return Response({'error': 'Email, OTP and new password are required'}, status=400)

        try:
            user = UserDetails.objects.get(Email_Address=email)
        except UserDetails.DoesNotExist:
            return Response({'error': 'User not found'}, status=404)

        try:
            record = EmailOTP.objects.get(email=user)
        except EmailOTP.DoesNotExist:
            return Response({'error': 'OTP not found'}, status=404)

        if record.otp != otp:
            return Response({'error': 'Invalid OTP'}, status=400)

        if (timezone.now() - record.created_at).total_seconds() > 300:
            return Response({'error': 'OTP expired'}, status=400)

        user.Password = new_password  # or use make_password(new_password) if hashed
        user.save()
        record.delete()

        return Response({'message': 'Password reset successfully ✅'}, status=200)

class ForgotPasswordView(APIView):
    def post(self, request):
        email = request.data.get("email")
        if not email:
            return Response({'error': 'Email is required'}, status=400)

        try:
            user = UserDetails.objects.get(Email_Address=email)
        except UserDetails.DoesNotExist:
            return Response({'error': 'User not found'}, status=404)

        otp = str(random.randint(100000, 999999))
        EmailOTP.objects.update_or_create(
            email=user,
            defaults={"otp": otp, "created_at": timezone.now()}
        )

        send_mail(
            subject="Reset OTP",
            message=f"Your OTP is: {otp}",
            from_email="noreply@otp.com",
            recipient_list=[user.Email_Address]
        )

        return Response({'message': 'OTP sent successfully'}, status=200)
class VerifyResetOTPView(APIView):
    def post(self, request):
        email = request.data.get("email")
        otp = request.data.get("otp")

        if not all([email, otp]):
            return Response({'error': 'Email and OTP are required'}, status=400)

        try:
            user = UserDetails.objects.get(Email_Address=email)
            record = EmailOTP.objects.get(email=user)
        except:
            return Response({'error': 'User or OTP not found'}, status=404)

        if record.otp != otp:
            return Response({'error': 'Invalid OTP'}, status=400)


        return Response({'message': 'OTP verified. Now set new password'}, status=200)
class SetNewPasswordView(APIView):
    def post(self, request):
        email = request.data.get("email")
        password = request.data.get("password")
        confirm_password = request.data.get("confirm_password")

        if not all([email, password, confirm_password]):
            return Response({'error': 'All fields required'}, status=400)

        if password != confirm_password:
            return Response({'error': 'Passwords do not match'}, status=400)

        try:
            user = UserDetails.objects.get(Email_Address=email)
        except UserDetails.DoesNotExist:
            return Response({'error': 'User not found'}, status=404)

        user.Password = password  # or make_password(password)
        user.save()

        # Clean up old OTPs
        EmailOTP.objects.filter(email=user).delete()

        # 🔥 Generate new token after password reset
        token = generate_token(user)

        return Response({
            'message': 'Password updated successfully ✅',
            'token': token
        }, status=200)

# class RegisterRequest(APIView):
#     def post(self, request):
#         user = request.user
#         otp = str(random.randint(000000, 999999))
#         EmailOTP.objects.update_or_create(
#             email=user,
#             otp = otp
#         )

#         send_mail(
#             subject="Your OTP Code",
#             message=f"Yo bruh, your OTP is {otp}",
#             from_email="noreply@otp.com",
#             recipient_list=[user.E],
#         )

#         return Response({'message': 'OTP sent to your email'})


# class LoginView(APIView):
#     def post(self, request):
#         email = request.data.get('email')
#         password = request.data.get('password')

#         if not email or not password:
#             return Response({'error': 'Email and Password required'}, status=400)

#         user = authenticate(username=email, password=password)

#         if user is None:
#             return Response({'error': 'Invalid login credentials'}, status=status.HTTP_401_UNAUTHORIZED)

#         return Response({'message': 'Login successful ✅'})